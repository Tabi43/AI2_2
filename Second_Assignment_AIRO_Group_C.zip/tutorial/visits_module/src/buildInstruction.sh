#!/bin/bash

mkdir ../build
cd ../build

cmake -DCMAKE_VERBOSE_MAKEFILE=TRUE -DCMAKE_BUILD_TYPE=Release ../src/

make
